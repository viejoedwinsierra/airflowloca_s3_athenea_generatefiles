# Project Documentation

## Simulation Context
This project simulates corporate blob storage behavior under normal and incident conditions.

## Duplicate Types
- HASH_RENAME
- NAME_COLLISION
- EXACT_DIFF_PATH
- NONE

## Metrics
- X_t
- D_t
- duplicate_rate
- volume_mb
